import math
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt


# Hyper Parameters
batch_size = 100
vocab_size = 10
epochs = 100
LR = 0.001


def get_all_data(df, batch_size):
    dfN = df.to_numpy()
    X, Y = [], []
    for i in range(math.ceil(len(dfN)/batch_size)):
        print("Getting {}/{} batch.".format(i, math.ceil(len(dfN)/batch_size)))
        X_batch, Y_batch = [], []
        for j in range(min(batch_size, len(dfN)-i*batch_size)):
            str1, str2, str3 = dfN[i*batch_size+1]
            strX1, strX2, strY = [0], [0], []
            for char in str1:
                strX1.append(int(char))
            for char in str2:
                strX2.append(int(char))
            for char in str3:
                strY.append(int(char))
            strX = (strX1, strX2)
            X_batch.append(strX)
            Y_batch.append(strY)
        X.append(X_batch)
        Y.append(Y_batch)
    steps = len(strX1)
    Xlen = len(X)
    X = np.array(X)
    Y = np.array(Y)

    return X, Y, steps, Xlen


def generator(data):
    i = 0
    iteator = iter(data)
    while True:
        try:
            X, Y = next(iteator)
            i += 1
        except:
            iteator = iter(data)
            X, Y = next(iteator)
            i = 1
        X = tf.one_hot(X, vocab_size)
        X = np.concatenate((X[:,0], X[:, 1]), axis=2)
        yield (X, Y)


def get_test_data(df, steps):
    dfN = df.to_numpy()
    X = []
    for i in range(len(dfN)):
        print("Getting {}/{} test data.".format(i, len(dfN)))
        str1, str2 = dfN[i]
        strX1, strX2 = [], []
        for j in range(steps-len(str1)):
            strX1.append(0)
            strX2.append(0)
        for char in str1:
            strX1.append(int(char))
        for char in str2:
            strX2.append(int(char))
        strX = (strX1, strX2)
        X.append(strX)
    steps = len(strX1)
    Xlen_test = len(X)
    X = np.array(X)
    X = tf.one_hot(X, vocab_size)
    X = np.concatenate((X[:,0], X[:, 1]), axis=2)
    return X, Xlen_test


# Loading train dataset
train_df = pd.read_csv("dataset/train.txt", header=None, delimiter=",")
X_train, Y_train, steps, Xlen_train = get_all_data(train_df, batch_size)
train_dataset = tf.data.Dataset.from_tensor_slices((X_train, Y_train))
train_gen = generator(train_dataset)

# Loading test dataset
df = pd.read_csv("dataset/test.txt", header=None, delimiter=",")
X_test, Xlen_test = get_test_data(df, steps)
path = 'C.txt'
f = open(path, "w")
output = []

# Model Training
model = tf.keras.Sequential()
model.add(keras.layers.Bidirectional(keras.layers.SimpleRNN(64, return_sequences=True), merge_mode='concat'))
model.add(keras.layers.Dropout(0.2))
model.add(keras.layers.Bidirectional(keras.layers.SimpleRNN(128, return_sequences=True), merge_mode='concat'))
model.add(keras.layers.Dropout(0.2))
model.add(keras.layers.Bidirectional(keras.layers.SimpleRNN(256, return_sequences=True), merge_mode='concat'))
model.add(keras.layers.Dropout(0.2))
model.add(keras.layers.Dense(vocab_size))

optimizer = keras.optimizers.Adam(learning_rate=LR)
loss = keras.losses.SparseCategoricalCrossentropy(from_logits=True)
model.compile(optimizer=optimizer, loss=loss, metrics=["accuracy"])

history = model.fit(x=train_gen, epochs=epochs, steps_per_epoch=64, verbose=1)

# Predicting
Y = model.predict(X_test)
Y = tf.argmax(Y, axis=-1)
Y = np.array(Y)
for i in range(len(Y)):
    Y1 = Y[i].tolist()
    Y1 = [str(p) for p in Y1]
    Y1 = ''.join(Y1)
    print(Y1, file=f)
f.close()

# summarize history for accuracy
plt.plot(history.history['accuracy'], "b-")
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.show()

# summarize history for loss
plt.plot(history.history['loss'], "y-")
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.show()